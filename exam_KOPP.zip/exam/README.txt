Bonjour,

J'ai utilisé Fastapi pour le tester principalement.
J'ai, toujorus dans la même optique, créé une classe et des focntions dans des fichiers distincts pour les importer.
J'ai utilisé pandas pour manipuler et corriger le fichier des questions.

Il manque un peu de commentaire dans le code et la doc de l'API.

Ce projet m'a apporté beaucoup de choses, merci !

Cordialement,